## React App Template

Clone or download this project to bootstrap a React project!

### Getting Started

Install the relevant `node_modules` and fire up the development server:

```
npm i && npm run dev
```